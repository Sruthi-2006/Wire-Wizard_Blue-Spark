#include <WiFi.h>
#include <HTTPClient.h>
#include <ArduinoJson.h>
#include <DHT.h>

// Hardware pins
#define DHTPIN 4
#define DHTTYPE DHT11
#define LDR_PIN 34
#define BUZZER_PIN 25

// Replace with your Wi-Fi details.
// Use a 2.4 GHz Wi-Fi network supported by ESP32.
const char* WIFI_SSID = "YOUR_WIFI_NAME";
const char* WIFI_PASSWORD = "YOUR_WIFI_PASSWORD";

// Replace with your laptop's IPv4 address from `ipconfig`.
// Do NOT use localhost here.
const char* SERVER_URL = "http://192.168.1.100:3001/api/esp32/data";
const char* CONFIG_URL = "http://192.168.1.100:3001/api/config";

DHT dht(DHTPIN, DHTTYPE);

float tempLimit = 35.0;
float humidityLimit = 80.0;
int lightLimit = 300;

// The included logic assumes a lower ADC reading means darker.
// Change to true if your module's ADC reading rises in darkness.
const bool LOW_LIGHT_IS_LOW_ADC = true;

const unsigned long SENSOR_INTERVAL = 2000;
const unsigned long CONFIG_INTERVAL = 10000;
const unsigned long BEEP_ON_TIME = 500;
const unsigned long BEEP_OFF_TIME = 1500;

unsigned long lastSensorRead = 0;
unsigned long lastConfigRead = 0;
unsigned long lastBeepChange = 0;
bool alertActive = false;
bool buzzerState = false;

void connectWiFi() {
  WiFi.mode(WIFI_STA);
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
  Serial.print("Connecting to Wi-Fi");
  unsigned long start = millis();
  while (WiFi.status() != WL_CONNECTED && millis() - start < 20000) {
    delay(500);
    Serial.print(".");
  }
  Serial.println();
  if (WiFi.status() == WL_CONNECTED) {
    Serial.print("Wi-Fi connected. ESP32 IP: ");
    Serial.println(WiFi.localIP());
  } else {
    Serial.println("Wi-Fi connection failed; will retry.");
  }
}

void fetchThresholds() {
  if (WiFi.status() != WL_CONNECTED) return;
  HTTPClient http;
  http.setTimeout(2500);
  http.begin(CONFIG_URL);
  int code = http.GET();
  if (code == HTTP_CODE_OK) {
    StaticJsonDocument<256> doc;
    DeserializationError error = deserializeJson(doc, http.getString());
    if (!error) {
      tempLimit = doc["temperature"] | tempLimit;
      humidityLimit = doc["humidity"] | humidityLimit;
      lightLimit = doc["lightAdc"] | lightLimit;
      Serial.printf("Thresholds updated: T=%.1f C, H=%.1f%%, LDR ADC=%d\n",
                    tempLimit, humidityLimit, lightLimit);
    }
  } else {
    Serial.printf("Config fetch failed: HTTP %d\n", code);
  }
  http.end();
}

void postReading(float temperature, float humidity, int lightAdc,
                 bool alert, bool buzzerOn) {
  if (WiFi.status() != WL_CONNECTED) return;

  HTTPClient http;
  http.setTimeout(3000);
  http.begin(SERVER_URL);
  http.addHeader("Content-Type", "application/json");

  StaticJsonDocument<256> doc;
  doc["temperature"] = temperature;
  doc["humidity"] = humidity;
  doc["lightAdc"] = lightAdc;
  doc["alert"] = alert;
  doc["buzzerOn"] = buzzerOn;

  String body;
  serializeJson(doc, body);
  int code = http.POST(body);
  Serial.printf("POST readings: HTTP %d\n", code);
  if (code > 0) Serial.println(http.getString());
  http.end();
}

void setup() {
  Serial.begin(115200);
  pinMode(BUZZER_PIN, OUTPUT);
  digitalWrite(BUZZER_PIN, LOW);
  pinMode(LDR_PIN, INPUT);
  analogReadResolution(12);
  dht.begin();
  connectWiFi();
}

void loop() {
  unsigned long now = millis();

  if (WiFi.status() != WL_CONNECTED) {
    static unsigned long lastWiFiAttempt = 0;
    if (now - lastWiFiAttempt >= 10000) {
      lastWiFiAttempt = now;
      WiFi.disconnect();
      WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
    }
  }

  if (now - lastConfigRead >= CONFIG_INTERVAL) {
    lastConfigRead = now;
    fetchThresholds();
  }

  if (now - lastSensorRead >= SENSOR_INTERVAL) {
    lastSensorRead = now;
    float temperature = dht.readTemperature();
    float humidity = dht.readHumidity();
    int lightAdc = analogRead(LDR_PIN);

    if (isnan(temperature) || isnan(humidity)) {
      Serial.println("DHT11 read error; buzzer forced OFF for safety.");
      alertActive = false;
      buzzerState = false;
      digitalWrite(BUZZER_PIN, LOW);
      return;
    }

    bool highTemperature = temperature > tempLimit;
    bool highHumidity = humidity > humidityLimit;
    bool lowLight = LOW_LIGHT_IS_LOW_ADC
      ? (lightAdc < lightLimit)
      : (lightAdc > lightLimit);

    bool newAlert = highTemperature || highHumidity || lowLight;
    if (newAlert && !alertActive) {
      buzzerState = true;
      lastBeepChange = now;
      digitalWrite(BUZZER_PIN, HIGH);
    }
    if (!newAlert) {
      buzzerState = false;
      digitalWrite(BUZZER_PIN, LOW);
    }
    alertActive = newAlert;

    Serial.printf("T=%.1f C | H=%.1f %% | LDR=%d | Alert=%s | Buzzer=%s\n",
      temperature, humidity, lightAdc,
      alertActive ? "YES" : "NO",
      buzzerState ? "ON" : "OFF");

    postReading(temperature, humidity, lightAdc, alertActive, buzzerState);
  }

  if (alertActive) {
    unsigned long interval = buzzerState ? BEEP_ON_TIME : BEEP_OFF_TIME;
    if (now - lastBeepChange >= interval) {
      lastBeepChange = now;
      buzzerState = !buzzerState;
      digitalWrite(BUZZER_PIN, buzzerState ? HIGH : LOW);
    }
  } else {
    buzzerState = false;
    digitalWrite(BUZZER_PIN, LOW);
  }

  delay(5);
}
