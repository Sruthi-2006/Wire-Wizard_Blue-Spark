import { useCallback, useEffect, useMemo, useState } from "react";
import {
  Activity, AlertTriangle, BellRing, CheckCircle2, ChevronRight, CircleHelp,
  Cloud, Gauge, Lightbulb, Radio, RefreshCw, Settings2, ShieldCheck,
  Thermometer, Wifi, WifiOff, Droplets, Clock3, SlidersHorizontal
} from "lucide-react";

const API = import.meta.env.VITE_API_URL || "http://localhost:3001";

const fallbackThresholds = { temperature: 35, humidity: 80, lightAdc: 300 };
const initialEvents = [
  { id: "welcome", type: "info", message: "Dashboard initialized. Waiting for sensor data.", timestamp: new Date().toISOString() }
];

function timeLabel(value) {
  if (!value) return "—";
  return new Date(value).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", second: "2-digit" });
}

function MetricCard({ title, value, unit, subtitle, icon: Icon, tone, progress, alert }) {
  return <article className={`metric-card ${alert ? "metric-alert" : ""}`}>
    <div className="metric-top">
      <div className={`metric-icon ${tone}`}><Icon size={20} /></div>
      <span className="metric-label">{title}</span>
      <span className={`mini-status ${alert ? "danger" : "good"}`}>{alert ? "ALERT" : "NORMAL"}</span>
    </div>
    <div className="metric-value">{value ?? "—"}<span>{unit}</span></div>
    <div className="metric-subtitle">{subtitle}</div>
    <div className="progress-track"><div className={`progress-fill ${tone}`} style={{ width: `${Math.max(0, Math.min(100, progress || 0))}%` }} /></div>
  </article>;
}

function App() {
  const [payload, setPayload] = useState(null);
  const [thresholds, setThresholds] = useState(fallbackThresholds);
  const [events, setEvents] = useState(initialEvents);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const [demoEnabled, setDemoEnabled] = useState(true);
  const [showSettings, setShowSettings] = useState(false);
  const [history, setHistory] = useState([]);

  const fetchData = useCallback(async () => {
    try {
      const [readingsRes, eventsRes] = await Promise.all([
        fetch(`${API}/api/readings`),
        fetch(`${API}/api/events`)
      ]);
      if (!readingsRes.ok || !eventsRes.ok) throw new Error("API request failed");
      const readings = await readingsRes.json();
      const eventData = await eventsRes.json();
      setPayload(readings);
      setThresholds(readings.thresholds || fallbackThresholds);
      setEvents(eventData.events || []);
      setError("");
      if (readings.reading) {
        setHistory(prev => {
          const next = [...prev, { ...readings.reading, time: Date.now() }].slice(-30);
          return next;
        });
      }
    } catch {
      setError("Backend unavailable. Start the Node.js API to receive demo or ESP32 readings.");
    }
  }, []);

  useEffect(() => {
    fetchData();
    const timer = setInterval(fetchData, 2000);
    return () => clearInterval(timer);
  }, [fetchData]);

  const reading = payload?.reading;
  const connected = Boolean(payload?.connected);
  const isDemo = payload?.mode === "demo";
  const conditions = reading || {};
  const alert = Boolean(conditions.alert);
  const reasons = [
    conditions.highTemperature && "High temperature",
    conditions.highHumidity && "High humidity",
    conditions.lowLight && "Low light"
  ].filter(Boolean);

  const saveThresholds = async () => {
    setBusy(true);
    try {
      const res = await fetch(`${API}/api/config`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(thresholds)
      });
      if (!res.ok) throw new Error("Could not save thresholds");
      const data = await res.json();
      setThresholds(data.thresholds);
      await fetchData();
    } catch {
      setError("Could not save thresholds. Check that the backend is running.");
    } finally {
      setBusy(false);
    }
  };

  const toggleDemo = async () => {
    try {
      const next = !demoEnabled;
      const res = await fetch(`${API}/api/demo`, {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ enabled: next })
      });
      if (res.ok) setDemoEnabled(next);
      await fetchData();
    } catch {
      setError("Could not update demo mode.");
    }
  };

  const trend = useMemo(() => history.slice(-18), [history]);

  return <div className="shell">
    <aside className="sidebar">
      <div className="brand">
        <div className="brand-mark"><Activity size={23} /></div>
        <div><div className="brand-name">EnviroGuard</div><div className="brand-caption">ENVIRONMENTAL INTELLIGENCE</div></div>
      </div>
      <div className="nav-section">WORKSPACE</div>
      <div className="nav-link active"><Gauge size={18} /> Overview <ChevronRight size={15} className="nav-chevron" /></div>
      <div className="nav-link"><Activity size={18} /> Sensor analytics</div>
      <div className="nav-link"><BellRing size={18} /> Alert history <span className="nav-count">{events.filter(e => e.type === "alert").length}</span></div>
      <div className="nav-link" onClick={() => setShowSettings(v => !v)} role="button" tabIndex={0}><SlidersHorizontal size={18} /> Threshold settings</div>
      <div className="sidebar-spacer" />
      <div className="device-card">
        <div className="device-card-head"><span className={`connection-dot ${connected ? "online" : isDemo ? "demo" : ""}`} /><strong>{connected ? "ESP32 online" : isDemo ? "Demo preview" : "Device offline"}</strong></div>
        <p>{connected ? "Receiving sensor packets over Wi-Fi." : "Connect the ESP32 to your local Wi-Fi to show real readings."}</p>
        <div className="device-meta"><Radio size={14} /> Device: ESP32 DevKit</div>
      </div>
      <div className="sidebar-foot">ENVIROGUARD <span>•</span> LOCAL NETWORK</div>
    </aside>

    <main className="main">
      <header className="topbar">
        <div>
          <div className="breadcrumb">Monitoring <ChevronRight size={13} /> Overview</div>
          <h1>Environmental overview</h1>
          <p className="page-subtitle">Monitor conditions, review alerts, and manage sensor thresholds.</p>
        </div>
        <div className="top-actions">
          <div className={`connection-pill ${connected ? "connected" : isDemo ? "demo" : "offline"}`}>
            {connected ? <Wifi size={16} /> : isDemo ? <Activity size={16} /> : <WifiOff size={16} />}
            {connected ? "ESP32 connected" : isDemo ? "Demo data" : "Waiting for device"}
          </div>
          <button className="icon-button" onClick={fetchData} title="Refresh readings"><RefreshCw size={17} /></button>
          <button className="primary-button" onClick={() => setShowSettings(v => !v)}><Settings2 size={16} /> Configure limits</button>
        </div>
      </header>

      {error && <div className="error-banner"><CircleHelp size={18} /><span>{error}</span></div>}

      <section className={`status-banner ${alert ? "status-alert" : "status-normal"}`}>
        <div className="status-symbol">{alert ? <AlertTriangle size={23} /> : <ShieldCheck size={23} />}</div>
        <div className="status-copy">
          <div className="status-kicker">SYSTEM HEALTH</div>
          <h2>{alert ? "Attention required" : reading ? "All monitored conditions normal" : "Waiting for readings"}</h2>
          <p>{alert ? `${reasons.join(" · ")}. The ESP32 buzzer should signal while any configured threshold is exceeded.` : "Sensor values are evaluated against the active threshold configuration."}</p>
        </div>
        <div className={`status-badge ${alert ? "danger" : "safe"}`}><span />{alert ? "ALERT ACTIVE" : "NORMAL"}</div>
      </section>

      <section className="section-heading">
        <div><h2>Live sensor readings</h2><p>Latest packet • refreshed every 2 seconds</p></div>
        <span className="updated-label"><Clock3 size={14} /> Updated {timeLabel(reading?.receivedAt || payload?.serverTime)}</span>
      </section>

      <section className="metric-grid">
        <MetricCard title="Temperature" value={reading ? Number(reading.temperature).toFixed(1) : "—"} unit="°C" subtitle={`Threshold: ${thresholds.temperature} °C`} icon={Thermometer} tone="temperature" progress={reading ? Number(reading.temperature) / 50 * 100 : 0} alert={Boolean(conditions.highTemperature)} />
        <MetricCard title="Relative humidity" value={reading ? Number(reading.humidity).toFixed(0) : "—"} unit="% RH" subtitle={`Threshold: ${thresholds.humidity} % RH`} icon={Droplets} tone="humidity" progress={reading ? Number(reading.humidity) : 0} alert={Boolean(conditions.highHumidity)} />
        <MetricCard title="Light intensity" value={reading ? Math.round(reading.lightAdc) : "—"} unit="ADC" subtitle={`Threshold: ${thresholds.lightAdc} ADC`} icon={Lightbulb} tone="light" progress={reading ? Number(reading.lightAdc) / 4095 * 100 : 0} alert={Boolean(conditions.lowLight)} />
      </section>

      <section className="content-grid">
        <article className="panel trend-panel">
          <div className="panel-heading"><div><h3>Sensor trend</h3><p>Recent samples received by this dashboard</p></div><span className="live-label"><span /> LIVE</span></div>
          {trend.length > 1 ? <div className="trend-chart">
            <div className="chart-legend"><span><i className="temp-dot" />Temperature</span><span><i className="humidity-dot" />Humidity</span><span><i className="light-dot" />Light (scaled)</span></div>
            <svg viewBox="0 0 720 220" preserveAspectRatio="none" role="img" aria-label="Recent sensor trend chart">
              {[35,75,115,155,195].map(y => <line key={y} x1="42" y1={y} x2="705" y2={y} className="chart-grid" />)}
              {[
                {key:"temperature", max:50, cls:"temp-line"},
                {key:"humidity", max:100, cls:"humidity-line"},
                {key:"lightAdc", max:4095, cls:"light-line"}
              ].map(series => {
                const points = trend.map((item, index) => `${42 + index * (663 / Math.max(1, trend.length - 1))},${195 - Math.max(0, Math.min(1, Number(item[series.key]) / series.max)) * 160}`).join(" ");
                return <polyline key={series.key} points={points} className={series.cls} />;
              })}
            </svg>
          </div> : <div className="empty-chart"><Activity size={26} /><strong>Collecting sensor history</strong><span>Trend lines appear after multiple readings arrive.</span></div>}
          <div className="chart-foot"><span>Earlier samples</span><span>Most recent</span></div>
        </article>

        <article className="panel threshold-panel" id="threshold-panel">
          <div className="panel-heading"><div><h3>Alert thresholds</h3><p>Limits used by backend and ESP32 firmware</p></div><SlidersHorizontal size={18} className="panel-icon" /></div>
          <div className="threshold-control">
            <div className="threshold-label"><span><Thermometer size={16} /> Temperature</span><strong>{thresholds.temperature} °C</strong></div>
            <input aria-label="Temperature threshold" type="range" min="15" max="60" value={thresholds.temperature} onChange={e => setThresholds(v => ({ ...v, temperature: Number(e.target.value) }))} />
          </div>
          <div className="threshold-control">
            <div className="threshold-label"><span><Droplets size={16} /> Humidity</span><strong>{thresholds.humidity} %</strong></div>
            <input aria-label="Humidity threshold" type="range" min="20" max="100" value={thresholds.humidity} onChange={e => setThresholds(v => ({ ...v, humidity: Number(e.target.value) }))} />
          </div>
          <div className="threshold-control">
            <div className="threshold-label"><span><Lightbulb size={16} /> Light ADC</span><strong>{thresholds.lightAdc}</strong></div>
            <input aria-label="Light threshold" type="range" min="0" max="4095" step="25" value={thresholds.lightAdc} onChange={e => setThresholds(v => ({ ...v, lightAdc: Number(e.target.value) }))} />
          </div>
          <button className="primary-button save-button" onClick={saveThresholds} disabled={busy}>{busy ? "Saving…" : "Save threshold settings"}</button>
          <p className="hint-text">Light alert currently assumes lower ADC readings indicate darker conditions. Calibrate this against your LDR module.</p>
        </article>
      </section>

      <section className="panel activity-panel">
        <div className="panel-heading"><div><h3>Recent activity</h3><p>Threshold changes and device events</p></div><span className="activity-count">{events.length} events</span></div>
        <div className="activity-list">
          {events.length ? events.slice(0, 6).map(event => <div className="activity-row" key={event.id}>
            <div className={`activity-icon ${event.type === "alert" ? "alert" : event.type === "normal" ? "normal" : "info"}`}>{event.type === "alert" ? <AlertTriangle size={17} /> : event.type === "normal" ? <CheckCircle2 size={17} /> : <Radio size={17} />}</div>
            <div className="activity-message"><strong>{event.type === "alert" ? "Threshold exceeded" : event.type === "normal" ? "Conditions normal" : "System event"}</strong><span>{event.message}</span></div>
            <time>{timeLabel(event.timestamp)}</time>
          </div>) : <div className="empty-events">No activity yet.</div>}
        </div>
      </section>

      <footer className="footer"><span>EnviroGuard</span> · ESP32 environmental monitoring · Local network dashboard <span className="footer-right">API: {API}</span></footer>
    </main>
  </div>;
}

export default App;
