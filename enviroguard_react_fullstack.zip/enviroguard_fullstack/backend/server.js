import express from "express";
import cors from "cors";

const app = express();
const PORT = Number(process.env.PORT || 3001);
app.use(cors());
app.use(express.json({ limit: "32kb" }));

const startedAt = Date.now();
let thresholds = { temperature: 35, humidity: 80, lightAdc: 300 };
let latest = null;
let lastReceivedAt = 0;
let demoEnabled = true;
const events = [];

function classify(data) {
  const highTemperature = Number(data.temperature) > thresholds.temperature;
  const highHumidity = Number(data.humidity) > thresholds.humidity;
  // Assumption: lower ADC reading means lower light. Calibrate for your LDR module.
  const lowLight = Number(data.lightAdc) < thresholds.lightAdc;
  return {
    highTemperature,
    highHumidity,
    lowLight,
    alert: highTemperature || highHumidity || lowLight
  };
}

function addEvent(type, message) {
  events.unshift({ id: `${Date.now()}-${Math.random().toString(16).slice(2)}`, type, message, timestamp: new Date().toISOString() });
  if (events.length > 30) events.length = 30;
}

function normalizeReading(body) {
  const temperature = Number(body.temperature);
  const humidity = Number(body.humidity);
  const lightAdc = Number(body.lightAdc);
  if (![temperature, humidity, lightAdc].every(Number.isFinite)) return null;
  if (temperature < -40 || temperature > 85 || humidity < 0 || humidity > 100 || lightAdc < 0 || lightAdc > 4095) return null;
  return {
    temperature,
    humidity,
    lightAdc: Math.round(lightAdc),
    deviceAlert: Boolean(body.alert),
    deviceBuzzer: Boolean(body.buzzerOn),
    source: "esp32",
    receivedAt: new Date().toISOString()
  };
}

app.get("/api/health", (_req, res) => res.json({ ok: true, uptimeSeconds: Math.round((Date.now() - startedAt) / 1000) }));

app.get("/api/readings", (_req, res) => {
  const connected = Boolean(latest && Date.now() - lastReceivedAt < 10000);
  if (connected) {
    const conditions = classify(latest);
    return res.json({ connected: true, mode: "esp32", reading: { ...latest, ...conditions }, thresholds, serverTime: new Date().toISOString() });
  }
  if (demoEnabled) {
    const reading = {
      temperature: 29 + Math.sin(Date.now() / 11000) * 4,
      humidity: 62 + Math.sin(Date.now() / 9000) * 15,
      lightAdc: Math.round(1700 + (Math.sin(Date.now() / 7000) + 1) * 1100),
      source: "demo",
      receivedAt: new Date().toISOString()
    };
    const conditions = classify(reading);
    return res.json({ connected: false, mode: "demo", reading: { ...reading, ...conditions }, thresholds, serverTime: new Date().toISOString() });
  }
  return res.json({ connected: false, mode: "offline", reading: null, thresholds, serverTime: new Date().toISOString() });
});

app.post("/api/esp32/data", (req, res) => {
  const reading = normalizeReading(req.body || {});
  if (!reading) return res.status(400).json({ error: "Invalid reading. Expected temperature, humidity and lightAdc within valid ranges." });
  const wasConnected = Boolean(latest && Date.now() - lastReceivedAt < 10000);
  latest = reading;
  lastReceivedAt = Date.now();
  demoEnabled = false;
  const conditions = classify(reading);
  if (conditions.alert !== Boolean(req.body.alert)) {
    // The server classification is authoritative for dashboard status; firmware uses the same thresholds.
  }
  const eventKey = `${conditions.highTemperature}-${conditions.highHumidity}-${conditions.lowLight}`;
  if (app.locals.lastEventKey !== eventKey) {
    app.locals.lastEventKey = eventKey;
    addEvent(conditions.alert ? "alert" : "normal", conditions.alert
      ? `Threshold exceeded: ${[
          conditions.highTemperature && "temperature",
          conditions.highHumidity && "humidity",
          conditions.lowLight && "low light"
        ].filter(Boolean).join(", ")}`
      : "All readings are within configured thresholds");
  }
  if (!wasConnected) addEvent("info", "ESP32 device connected");
  res.json({ ok: true, thresholds, ...conditions });
});

app.get("/api/config", (_req, res) => res.json(thresholds));

app.put("/api/config", (req, res) => {
  const temperature = Number(req.body.temperature);
  const humidity = Number(req.body.humidity);
  const lightAdc = Number(req.body.lightAdc);
  if (!Number.isFinite(temperature) || temperature < 0 || temperature > 80 ||
      !Number.isFinite(humidity) || humidity < 0 || humidity > 100 ||
      !Number.isFinite(lightAdc) || lightAdc < 0 || lightAdc > 4095) {
    return res.status(400).json({ error: "Threshold values are outside allowed ranges." });
  }
  thresholds = { temperature, humidity, lightAdc };
  addEvent("info", `Thresholds updated: ${temperature} °C, ${humidity}% RH, light ADC ${lightAdc}`);
  res.json({ ok: true, thresholds });
});

app.get("/api/events", (_req, res) => res.json({ events }));

app.post("/api/demo", (req, res) => {
  demoEnabled = Boolean(req.body.enabled);
  res.json({ ok: true, demoEnabled });
});

app.listen(PORT, "0.0.0.0", () => {
  console.log(`EnviroGuard API running at http://0.0.0.0:${PORT}`);
});
